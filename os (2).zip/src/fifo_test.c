/*
 * Multi-Agent AI Execution System
 * CO-5: File System Test Module
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>

#define TEST_FILE "co5_test.txt"

int main(void)
{
    printf("\n========================================\n");
    printf("          CO-5 FILE SYSTEM TEST\n");
    printf("========================================\n");

    /* Create and open file */
    int fd = open(
        TEST_FILE,
        O_CREAT | O_RDWR | O_TRUNC,
        0644
    );

    if (fd == -1)
    {
        perror("open()");
        return 1;
    }

    printf("[TEST] File created successfully\n");
    printf("[TEST] File descriptor: %d\n", fd);

    /* Write data */
    const char *data =
        "CO-5 File System and File I/O Test\n";

    ssize_t written = write(
        fd,
        data,
        strlen(data)
    );

    if (written == -1)
    {
        perror("write()");
        close(fd);
        return 1;
    }

    printf("[TEST] write() successful\n");
    printf("[TEST] Bytes written: %ld\n",
           (long)written);

    /* Move file offset */
    if (lseek(fd, 0, SEEK_SET) == (off_t)-1)
    {
        perror("lseek()");
        close(fd);
        return 1;
    }

    printf("[TEST] lseek() successful\n");

    /* Read data */
    char buffer[100];

    ssize_t bytes_read = read(
        fd,
        buffer,
        sizeof(buffer) - 1
    );

    if (bytes_read == -1)
    {
        perror("read()");
        close(fd);
        return 1;
    }

    buffer[bytes_read] = '\0';

    printf("[TEST] read() successful\n");
    printf("[TEST] Data: %s", buffer);

    /* File information */
    struct stat info;

    if (stat(TEST_FILE, &info) == 0)
    {
        printf("[TEST] File size: %ld bytes\n",
               (long)info.st_size);
    }

    close(fd);

    printf("[TEST] File descriptor closed\n");

    printf("========================================\n");
    printf("       CO-5 TEST PASSED\n");
    printf("========================================\n\n");

    return 0;
}
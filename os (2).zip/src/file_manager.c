/*
 * Multi-Agent AI Execution System
 * CO-5: File Systems and File I/O
 *
 * Demonstrates:
 * - File descriptors
 * - open(), read(), write(), close()
 * - lseek()
 * - stat()
 * - Buffered I/O
 * - Memory-mapped file I/O
 * - File locking
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/file.h>

#define FILE_NAME "agent_execution.log"

int main(void)
{
    const char *message =
        "Multi-Agent AI Execution System - CO5 File I/O\n";

    printf("\n========================================\n");
    printf("       CO-5 FILE SYSTEM MODULE\n");
    printf("========================================\n");

    /* -----------------------------------
       1. File Descriptor and open()
       ----------------------------------- */

    int fd = open(
        FILE_NAME,
        O_CREAT | O_RDWR | O_TRUNC,
        0644
    );

    if (fd == -1)
    {
        perror("[CO5] open()");
        return 1;
    }

    printf("[CO5] File opened successfully\n");
    printf("[CO5] File descriptor: %d\n", fd);

    /* -----------------------------------
       2. File Locking
       ----------------------------------- */

    if (flock(fd, LOCK_EX) == -1)
    {
        perror("[CO5] flock()");
        close(fd);
        return 1;
    }

    printf("[CO5] Exclusive file lock acquired\n");

    /* -----------------------------------
       3. write()
       ----------------------------------- */

    ssize_t written = write(
        fd,
        message,
        strlen(message)
    );

    if (written == -1)
    {
        perror("[CO5] write()");
        flock(fd, LOCK_UN);
        close(fd);
        return 1;
    }

    printf("[CO5] write() successful: %ld bytes\n",
           (long)written);

    /* -----------------------------------
       4. lseek()
       ----------------------------------- */

    off_t position = lseek(fd, 0, SEEK_SET);

    if (position == (off_t)-1)
    {
        perror("[CO5] lseek()");
        flock(fd, LOCK_UN);
        close(fd);
        return 1;
    }

    printf("[CO5] File offset reset using lseek()\n");

    /* -----------------------------------
       5. read()
       ----------------------------------- */

    char buffer[256];

    ssize_t bytes_read = read(
        fd,
        buffer,
        sizeof(buffer) - 1
    );

    if (bytes_read == -1)
    {
        perror("[CO5] read()");
        flock(fd, LOCK_UN);
        close(fd);
        return 1;
    }

    buffer[bytes_read] = '\0';

    printf("[CO5] read() successful\n");
    printf("[CO5] File content: %s", buffer);

    /* -----------------------------------
       6. stat()
       ----------------------------------- */

    struct stat file_info;

    if (stat(FILE_NAME, &file_info) == -1)
    {
        perror("[CO5] stat()");
    }
    else
    {
        printf("[CO5] File size: %ld bytes\n",
               (long)file_info.st_size);

        printf("[CO5] File permissions: %o\n",
               file_info.st_mode & 0777);
    }

    /* -----------------------------------
       7. Buffered I/O
       ----------------------------------- */

    FILE *fp = fopen(FILE_NAME, "a");

    if (fp != NULL)
    {
        fprintf(
            fp,
            "[CO5] Buffered I/O completed\n"
        );

        fclose(fp);

        printf("[CO5] Buffered I/O using FILE* successful\n");
    }
    else
    {
        perror("[CO5] fopen()");
    }

    /* -----------------------------------
       8. Memory-Mapped File I/O
       ----------------------------------- */

    size_t file_size = (size_t)lseek(
        fd,
        0,
        SEEK_END
    );

    if (file_size > 0)
    {
        void *mapped = mmap(
            NULL,
            file_size,
            PROT_READ | PROT_WRITE,
            MAP_SHARED,
            fd,
            0
        );

        if (mapped != MAP_FAILED)
        {
            printf("[CO5] Memory-mapped I/O successful\n");

            munmap(mapped, file_size);
        }
        else
        {
            perror("[CO5] mmap()");
        }
    }

    /* -----------------------------------
       9. Unlock and close
       ----------------------------------- */

    flock(fd, LOCK_UN);

    printf("[CO5] File lock released\n");

    close(fd);

    printf("[CO5] File descriptor closed\n");

    printf("========================================\n");
    printf("       CO-5 COMPLETED SUCCESSFULLY\n");
    printf("========================================\n\n");

    return 0;
}